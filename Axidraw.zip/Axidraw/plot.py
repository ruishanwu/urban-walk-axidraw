#/dev/tty.usbserial-A90LXQ1C
import serial


import time
import random
import pyautogui
import tkinter as tk
from pyaxidraw import axidraw
import threading

ser = serial.Serial('/dev/tty.usbserial-A90LXQ1C', 9600)

# 创建一个Axidraw的实例
ad = axidraw.AxiDraw()


# 设置SVG文件的路径
svg_file_paths = [
    "svg/Kowloon Walled City.svg",
    "svg/Fruit Market.svg",
    "svg/Lui Seng Chun.svg",
    "svg/Ding Ding.svg",
    "svg/Central Market.svg",
    "svg/Monster Building.svg",
    "svg/Star Ferry.svg",
    "svg/State Theater.svg"
]


def plot_svg(svg_file_path):
    ad.plot_setup(svg_file_path)
    ad.plot_run()


# 进入无限循环
while True:
    # read a line from the serial port
    line = ser.readline().decode('utf-8').strip()

    # parse the GSR value from the line
    try:
        gsr_value = int(line)
    except ValueError:
        print("无法解析的数据：", line)
        continue

    # do something with the GSR value
    print("GSR value:", gsr_value)

    # 如果信号值达到200，或者输入为"done"，开始绘制
    if gsr_value <= 200:
        # 随机选择一个SVG文件进行绘制
        svg_file_path = random.choice(svg_file_paths)
        plot_svg(svg_file_path)
        # 清除gsr_value的值
        print("done")
        time.sleep(30)
        ser.reset_input_buffer()  # 清空串口缓冲区







