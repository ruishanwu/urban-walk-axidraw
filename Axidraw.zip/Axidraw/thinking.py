from pyaxidraw import axidraw
import time

# 初始化AxiDraw类
ad = axidraw.AxiDraw()

# 进入交互模式

ad.interactive()            # Enter interactive mode
connected = ad.connect()    # Open serial port to AxiDraw

ad.penup()
# 循环进行上下浮动
while True:

    # Change some options, just to show how we do so:

    ad.options.pen_pos_down = 40
    ad.options.pen_pos_up = 60
    ad.update()  # Process changes to options

    ad.pendown()
    time.sleep(1.0)
    ad.penup()
    time.sleep(1.0)

    ad.options.pen_pos_down = 20
    ad.options.pen_pos_up = 100

    ad.update()  # Process changes to options

    ad.pendown()
    ad.penup()
    time.sleep(60)





'''
# Lift the pen
#ad.penup()
# 获取当前位置
current_position = ad.turtle_pos()

# 打印当前位置
print(f"Current position: X = {current_position[0]}, Y = {current_position[1]}")

# Move to home position (0,0)
ad.moveto(0,0)

'''