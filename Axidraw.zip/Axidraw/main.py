import sys
import os.path
from pyaxidraw import axidraw


ad = axidraw.AxiDraw()             # Create class instance

LOCATION1 = "svg/Kowloon Walled City.svg"
LOCATION2 = "svg/Fruit Market.svg"
LOCATION3 = "svg/Lui Seng Chun.svg"
LOCATION4 = "svg/Ding Ding.svg"
LOCATION5 = "svg/Central Market.svg"
LOCATION6 = "svg/Monster Building.svg"
LOCATION7 = "svg/Star Ferry.svg"
LOCATION8 = "svg/State Theater.svg"

FILE = None

if os.path.exists(LOCATION1):
    FILE = LOCATION1
if os.path.exists(LOCATION2):
    FILE = LOCATION2
if os.path.exists(LOCATION3):
    FILE = LOCATION3
if os.path.exists(LOCATION4):
    FILE = LOCATION4
if os.path.exists(LOCATION5):
    FILE = LOCATION5
if os.path.exists(LOCATION6):
    FILE = LOCATION6
if os.path.exists(LOCATION7):
    FILE = LOCATION7
if os.path.exists(LOCATION8):
    FILE = LOCATION8

if FILE:
    print("Example file located at: " + FILE)
    ad.plot_setup(FILE)    # Parse the input file
else:
    print("Unable to locate example file; exiting.")
    sys.exit() # end script

# The above code, starting with "LOCATION1" can all be replaced by a single line
# if you already know where the file is. This can be as simple as:
# ad.plot_setup("AxiDraw_trivial.svg")

ad.options.speed_pendown = 50 # Set maximum pen-down speed to 50%


ad.plot_run()   # plot the document